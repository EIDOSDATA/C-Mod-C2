Binary File
===

This directory contains external files need for building applications.
These versions have been tested - don't replace

These files are copied to PackageFiles\bin\i386-win-gnu during the build process

The following are from wxwidgets 
==
wxbase311u_gcc_custom.dll
wxbase311u_net_gcc_custom.dll
wxmsw311u_adv_gcc_custom.dll
wxmsw311u_core_gcc_custom.dll

Source: http://www.wxwidgets.org/  
License: http://www.wxwidgets.org/about/licence/  

The following are from MinGW 
==
libgcc_s_dw2-1.dll
libstdc++-6.dll

Source: http://www.mingw.org/  
License: http://www.mingw.org/license  

The following are from LibUSB 
==
libusb-1.0.dll

Source: 
License: 
