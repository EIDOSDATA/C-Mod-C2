This directory contains external files need for USBDM.
These versions have been tested - don't replace