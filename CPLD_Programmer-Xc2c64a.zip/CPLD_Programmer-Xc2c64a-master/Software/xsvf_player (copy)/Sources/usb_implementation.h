/**
 * @file     usb_implementation.h
 * @brief    USB Kinetis implementation
 *
 * @version  V4.12.1.150
 * @date     13 Nov 2016
 */

/*
 * Include appropriate example
 */
//#include "usb_implementation_cdc.h"
#include "usb_implementation_bulk.h"
//#include "usb_implementation_composite.h"
