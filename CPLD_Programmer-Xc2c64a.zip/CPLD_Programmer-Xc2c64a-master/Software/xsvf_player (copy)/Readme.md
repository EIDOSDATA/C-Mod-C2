# xsvf_player
Microcontroller project to play a XSVF file transferred over USB to JTAG interface.