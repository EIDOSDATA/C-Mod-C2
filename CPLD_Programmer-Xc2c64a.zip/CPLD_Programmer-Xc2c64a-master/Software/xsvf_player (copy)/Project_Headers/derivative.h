/**
 * @file     derivative.h
 * @brief    Include the derivative-specific header file MK20D5.h
 * @version  V4.11.1.70
 * @date     13 Nov 2012
 */
#include "MK20D5.h"
