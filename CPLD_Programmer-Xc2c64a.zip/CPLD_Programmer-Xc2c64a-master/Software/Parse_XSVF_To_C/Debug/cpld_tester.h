/*
 * cpld_tester.h
 *
 *  Created on: 16 Dec 2019
 *      Author: podonoghue
 */

#ifndef SOURCES_cpld_tester_H_
#define SOURCES_cpld_tester_H_

#include <stdint.h>

extern const uint8_t cpld_tester[22928];

#endif /* SOURCES_cpld_tester_H_ */
