# Parse_XSVF_To_C
Convert XSVF file to C array with readable format