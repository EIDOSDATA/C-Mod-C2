# CPLD Programmer Application for Windows

This is a basic GUI programmer for a particular CPLD.
It works with the xsvf_player in the programming hardware