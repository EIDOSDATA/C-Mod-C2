# xsvf_rom_player
Microcontroller project to play XSVF file from array to JTAG interface.