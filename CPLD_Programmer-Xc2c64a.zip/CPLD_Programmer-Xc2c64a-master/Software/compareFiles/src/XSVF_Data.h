/*
 * XSVF_Data2.h
 *
 *  Created on: 16 Dec 2019
 *      Author: podonoghue
 */

#ifndef SOURCES_XSVF_DATA_H_
#define SOURCES_XSVF_DATA_H_

#include <stdint.h>

extern const uint8_t xsvf_data[22928];

#endif /* SOURCES_XSVF_DATA_H_ */
