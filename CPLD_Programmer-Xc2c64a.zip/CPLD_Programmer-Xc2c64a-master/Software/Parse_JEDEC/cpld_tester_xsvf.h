/*
 * cpld_tester
 *
 *  Created on: 16 Dec 2019
 *      Author: podonoghue
 */

#ifndef SOURCES_cpld_tester_xsvf_H_
#define SOURCES_cpld_tester_xsvf_H_

#include <stdint.h>

extern const uint8_t cpld_tester_xsvf[22525];

#endif /* SOURCES_cpld_tester_xsvf_H_ */
