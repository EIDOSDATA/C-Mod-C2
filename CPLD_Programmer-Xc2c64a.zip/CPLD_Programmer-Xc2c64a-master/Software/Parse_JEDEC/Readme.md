# Parse_JEDEC
Parse JEDEC file