# GenerateTables
Generate JTAG state and transition path tables