# CPLD Programmer Installer for Windows

This is a WIX project to create a Windows installer