# Hardware test programs for CPLD breakout

- cpld_simple - Simply connects the Reset pin to the LED pin
- cpld_tester - Toggles all pins (required clock)
